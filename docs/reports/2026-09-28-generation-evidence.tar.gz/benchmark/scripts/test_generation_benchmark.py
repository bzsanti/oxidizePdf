import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('generation', Path(__file__).with_name('generation_benchmark.py'))
generation = importlib.util.module_from_spec(spec)
spec.loader.exec_module(generation)

class StatisticsTests(unittest.TestCase):
    def test_batch_latency_and_throughput_have_explicit_denominators(self):
        rows = [dict(documents=1000, pages_per_document=10, elapsed_ns=n*1_000_000_000,
                     peak_rss_kib=1024*n, output_bytes=100_000) for n in [1,2,3,4]]
        result = generation.summarize(rows)
        self.assertEqual(result['median_ms_per_document'], 2.5)
        self.assertEqual(result['p95_ms_per_document'], 4)
        self.assertAlmostEqual(result['median_documents_per_second'], (500+1000/3)/2)
        self.assertEqual(result['mean_output_bytes'], 100)
        self.assertEqual(result['max_process_rss_kib'], 4096)
        self.assertEqual(result['throughput_median_ci95'], generation.summarize(rows)['throughput_median_ci95'])

    def test_invalid_measurements_are_not_successes(self):
        with self.assertRaises(ValueError): generation.summarize([])
        row=dict(documents=1000,pages_per_document=1,elapsed_ns=0,peak_rss_kib=1024,output_bytes=100)
        with self.assertRaises(ValueError): generation.summarize([row])

    def test_all_five_engines_share_both_workloads(self):
        self.assertEqual(set(generation.LIBRARIES), {"oxidize-pdf", "lopdf", "pdf-writer", "printpdf", "pdf_oxide"})
        self.assertEqual(generation.SCENARIOS, {"invoice-1p": (1, 1000), "report-10p": (10, 100)})

    def test_p95_nearest_rank(self):
        self.assertEqual(generation.quantile(list(range(1,21)), .95), 19)

if __name__ == '__main__':
    unittest.main()

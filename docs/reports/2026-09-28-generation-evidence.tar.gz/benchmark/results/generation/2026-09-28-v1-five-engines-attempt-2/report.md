# PDF generation performance

Synthetic text-only workload on one shared host; defaults differ in compression/metadata. Batch-average p95 is not individual-request p95. Bootstrap describes run-level samples, not other hardware or real workloads. No PDFSharp, QuestPDF or IronPDF comparison, leak, image/font or deployment-size claim.

| Library | Version | Workload | Documents/s median | Batch-average ms/doc p95 | Process peak MiB | Bytes/doc |
|---|---|---|---:|---:|---:|---:|
| oxidize-pdf | 5.1.5 | invoice-1p | 6311.4 | 0.197 | 5.0 | 5015 |
| oxidize-pdf | 5.1.5 | report-10p | 732.4 | 1.587 | 5.4 | 20452 |
| lopdf | 0.44.0 | invoice-1p | 25780.3 | 0.047 | 3.6 | 2124 |
| lopdf | 0.44.0 | report-10p | 2999.0 | 0.472 | 3.8 | 17649 |
| pdf-writer | 0.15.0 | invoice-1p | 116236.9 | 0.015 | 3.4 | 2206 |
| pdf-writer | 0.15.0 | report-10p | 13064.2 | 0.134 | 3.5 | 18924 |
| printpdf | 0.12.7 | invoice-1p | 8707.0 | 0.175 | 4.4 | 1551 |
| printpdf | 0.12.7 | report-10p | 957.8 | 1.445 | 4.9 | 7307 |
| pdf_oxide | 0.3.78 | invoice-1p | 6630.9 | 0.215 | 4.2 | 3816 |
| pdf_oxide | 0.3.78 | report-10p | 923.2 | 1.494 | 4.5 | 22781 |

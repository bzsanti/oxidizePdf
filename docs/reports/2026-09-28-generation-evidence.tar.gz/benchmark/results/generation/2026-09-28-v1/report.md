# PDF generation performance

Synthetic text-only workload on one shared host; defaults differ in compression/metadata. Batch-average p95 is not individual-request p95. Bootstrap describes run-level samples, not other hardware or real workloads. No PDFSharp, QuestPDF or IronPDF comparison, leak, image/font or deployment-size claim.

| Library | Version | Workload | Documents/s median | Batch-average ms/doc p95 | Process peak MiB | Bytes/doc |
|---|---|---|---:|---:|---:|---:|
| oxidize-pdf | 5.1.5 | invoice-1p | 3956.5 | 0.258 | 4.5 | 5015 |
| oxidize-pdf | 5.1.5 | report-10p | 458.6 | 2.226 | 4.9 | 20466 |
| lopdf | 0.44.0 | invoice-1p | 25303.3 | 0.041 | 3.2 | 2124 |
| lopdf | 0.44.0 | report-10p | 3142.0 | 0.324 | 3.4 | 17649 |
| pdf-writer | 0.15.0 | invoice-1p | 85999.8 | 0.012 | 3.1 | 2206 |
| pdf-writer | 0.15.0 | report-10p | 10002.1 | 0.105 | 3.2 | 18924 |
| printpdf | 0.12.7 | invoice-1p | 4953.8 | 0.208 | 3.9 | 1551 |
| printpdf | 0.12.7 | report-10p | 564.9 | 1.844 | 4.4 | 7307 |

#!/usr/bin/env python3
"""Run generation-v1; raw samples and independent PDF validation before summary."""
import argparse
import collections
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import re
import statistics
import subprocess
import time

PROTOCOL = 'pdf-generation-v1'
LIBRARIES = ['oxidize-pdf', 'lopdf', 'pdf-writer', 'printpdf']
SCENARIOS = {'invoice-1p': (1, 1000), 'report-10p': (10, 100)}
ROOT = Path(__file__).resolve().parents[2]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(args, **kwargs):
    return subprocess.run([str(x) for x in args], check=True, capture_output=True, text=True,
                          timeout=kwargs.pop('timeout', 180), **kwargs)


def quantile(values, p):
    """Nearest-rank percentile, never interpolate throughput and latency."""
    return sorted(values)[math.ceil(len(values) * p) - 1]


def summarize(samples):
    if not samples:
        raise ValueError('empty population')
    for row in samples:
        for key in ('documents', 'pages_per_document', 'elapsed_ns', 'peak_rss_kib', 'output_bytes'):
            if type(row[key]) is not int or row[key] <= 0:
                raise ValueError('invalid sample: ' + key)
    latency = [s['elapsed_ns'] / s['documents'] / 1e6 for s in samples]
    throughput = [s['documents'] * 1e9 / s['elapsed_ns'] for s in samples]
    # Reproducible percentile bootstrap of the run-level median; descriptive only.
    rng = random.Random(603)
    bootstrap = sorted(statistics.median(rng.choices(throughput, k=len(throughput))) for _ in range(2000))
    return {
        'samples': len(samples), 'documents_per_sample': samples[0]['documents'],
        'pages_per_document': samples[0]['pages_per_document'],
        'median_ms_per_document': statistics.median(latency),
        'p95_ms_per_document': quantile(latency, .95),
        'median_documents_per_second': statistics.median(throughput),
        'median_pages_per_second': statistics.median(throughput) * samples[0]['pages_per_document'],
        'throughput_median_ci95': [quantile(bootstrap, .025), quantile(bootstrap, .975)],
        'max_process_rss_kib': max(s['peak_rss_kib'] for s in samples),
        'mean_output_bytes': sum(s['output_bytes'] for s in samples) / sum(s['documents'] for s in samples),
    }


def validate_pdf(path, pages):
    command(['qpdf', '--check', path])  # warnings/nonzero are failures too
    if int(command(['qpdf', '--show-npages', path]).stdout) != pages:
        raise ValueError('page count mismatch')
    text = command(['pdftotext', '-layout', path, '-']).stdout
    actual = [line.strip() for line in text.replace('\f', '\n').splitlines() if line.strip()]
    expected = []
    for page in range(1, pages + 1):
        expected.append(f'Invoice benchmark | Page {page:04}/{pages:04}')
        expected.extend(f'Item {item:02} | Qty 2 | Unit 12.50 | Total 25.00' for item in range(1, 21))
        expected.append('TOTAL 500.00 EUR')
    if actual != expected:
        raise ValueError(f'extracted content differs: {actual[:3]} (expected {len(expected)} lines, got {len(actual)})')
    return {'qpdf_check': True, 'pages': pages, 'exact_text': True, 'sha256': digest(path)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--samples', type=int, default=20)
    parser.add_argument('--offline', action='store_true')
    args = parser.parse_args()
    if not 5 <= args.samples <= 100:
        parser.error('samples must be 5..100; use 20 or more for reported results')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)  # never overwrite/resume a population
    crate = ROOT / 'benchmark/generation'
    offline = ['--offline'] if args.offline else []
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        metadata = json.loads(command(['cargo', 'metadata', '--manifest-path', crate/'Cargo.toml', '--locked', '--format-version', '1', *offline], timeout=300).stdout)
        packages = {}
        for name in LIBRARIES:
            matches = [p for p in metadata['packages'] if p['name'] == name]
            if len(matches) != 1 or not (matches[0]['source'] or '').startswith('registry+'):
                raise ValueError('expected one registry package: ' + name)
            packages[name] = {'version': matches[0]['version'], 'source': matches[0]['source']}
        command(['cargo', 'build', '--release', '--locked', '-j', '2', '--manifest-path', crate/'Cargo.toml', *offline], timeout=1800)
        binary = Path(metadata['target_directory'])/'release/pdf-generation-benchmark'
        source_files = [crate/'Cargo.toml', crate/'Cargo.lock', crate/'src/main.rs', Path(__file__)]
        hashes = {str(p.relative_to(ROOT)): digest(p) for p in source_files}
        for p in source_files:
            (output/p.name).write_bytes(p.read_bytes())
        cpu = next((line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')), 'unknown')
        environment = {
            'os': platform.platform(), 'cpu': cpu, 'logical_cpus': os.cpu_count(),
            'affinity': sorted(os.sched_getaffinity(0)), 'rustc': command(['rustc', '-Vv']).stdout,
            'cargo': command(['cargo', '-V']).stdout.strip(), 'profile': 'release',
            'rustflags': os.environ.get('RUSTFLAGS', ''), 'load_before': os.getloadavg(),
            'qpdf': command(['qpdf', '--version']).stdout.strip(),
            'pdftotext': command(['pdftotext', '-v']).stderr.strip(),
        }
        manifest = {'protocol': PROTOCOL, 'started_at': started, 'packages': packages,
                    'source_sha256': hashes, 'binary_sha256': digest(binary), 'environment': environment,
                    'samples_per_case': args.samples, 'scenario_documents': SCENARIOS,
                    'ordering': 'seed603-shuffled-complete-blocks', 'warmup_documents_per_process': 3,
                    'timing_scope': 'construction+serialization+buffer-drop, memory output; excludes startup/warmup/validation/IO',
                    'rss_scope': 'GNU time process peak KiB, includes runtime/warmup/representative-output IO; not incremental allocation',
                    'configuration': 'same Helvetica 10pt, A4, 22 text lines per page; adapter default serialization/compression',
                    'limitations': 'Synthetic text-only workload on one shared host; defaults differ in compression/metadata. Batch-average p95 is not individual-request p95. Bootstrap describes run-level samples, not other hardware or real workloads. No PDFSharp, QuestPDF or IronPDF comparison, leak, image/font or deployment-size claim.'}
        (output/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
        rng = random.Random(603)
        groups = collections.defaultdict(list)
        with (output/'samples.jsonl').open('w') as log:
            for block in range(args.samples):
                cases = [(lib, scenario) for lib in LIBRARIES for scenario in SCENARIOS]
                rng.shuffle(cases)
                for library, scenario in cases:
                    pages, documents = SCENARIOS[scenario]
                    name = f'{library}-{scenario}-{block:02}'
                    pdf = output/(name+'.pdf')
                    memory = output/(name+'.rss-kib.txt')
                    start = time.monotonic()
                    result = command(['/usr/bin/time', '-f', '%M', '-o', memory, binary, library, scenario, pdf, documents])
                    sample = json.loads(result.stdout)
                    if sample['documents'] != documents or sample['pages_per_document'] != pages or sample['warmup_documents'] != 3:
                        raise ValueError('runner protocol mismatch')
                    sample.update({'library': library, 'version': packages[library]['version'], 'scenario': scenario,
                                   'block': block, 'peak_rss_kib': int(memory.read_text()),
                                   'process_wall_seconds': time.monotonic()-start, 'load': os.getloadavg(),
                                   'validation': validate_pdf(pdf, pages)})
                    groups[library, scenario].append(sample)
                    log.write(json.dumps(sample)+'\n'); log.flush()
                    print(f'{block+1}/{args.samples} {library} {scenario}', flush=True)
        # Refuse a mixed-source run if an editor changed the benchmark during execution.
        if any(digest(ROOT/p) != h for p, h in hashes.items()):
            raise ValueError('benchmark source changed during execution')
        rows = [{'library': lib, 'version': packages[lib]['version'], 'scenario': scenario, **summarize(groups[lib, scenario])}
                for lib in LIBRARIES for scenario in SCENARIOS]
        report = {'protocol': PROTOCOL, 'started_at': started, 'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  'manifest_sha256': digest(output/'manifest.json'), 'samples_sha256': digest(output/'samples.jsonl'),
                  'environment': environment, 'limitations': manifest['limitations'], 'rows': rows}
        (output/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
        (output/'report.md').write_text('# PDF generation performance\n\n'+manifest['limitations']+'\n\n'
            '| Library | Version | Workload | Documents/s median | Batch-average ms/doc p95 | Process peak MiB | Bytes/doc |\n'
            '|---|---|---|---:|---:|---:|---:|\n'+''.join(
                f"| {r['library']} | {r['version']} | {r['scenario']} | {r['median_documents_per_second']:.1f} | {r['p95_ms_per_document']:.3f} | {r['max_process_rss_kib']/1024:.1f} | {r['mean_output_bytes']:.0f} |\n" for r in rows))
        print(output/'report.md')
    except Exception as error:
        (output/'failure.json').write_text(json.dumps({'error': str(error), 'started_at': started}, indent=2)+'\n')
        raise


if __name__ == '__main__':
    main()

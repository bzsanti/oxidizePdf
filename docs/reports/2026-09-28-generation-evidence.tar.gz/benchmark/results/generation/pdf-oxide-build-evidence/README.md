# pdf_oxide 0.3.78 dependency resolution

The registry release was fetched with `cargo info pdf_oxide`. Its normalized
manifest requires `office_oxide = "0.1.9"` without default features. A fresh
compatible resolution selected 0.1.12; `cargo check` failed in the unmodified
pdf_oxide source at `src/converters/pdf_to_ir.rs:194`:

```
error[E0063]: missing field `defined_names` in initializer of `DocumentIR`
```

The full compiler output is retained in `unconstrained-office-0.1.12.log`.
The Cargo.lock distributed inside pdf_oxide 0.3.78 records office_oxide 0.1.9.
The benchmark therefore pins that registry dependency to =0.1.9, without changing
pdf_oxide source or falling back to a Git/path implementation. The successful
check output is retained separately. The final run's Cargo.lock identifies every
resolved package and checksum; no result is attributed to the failed resolution.

Registry/API reference: https://docs.rs/pdf_oxide/0.3.78/pdf_oxide/

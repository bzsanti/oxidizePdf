use std::{error::Error, hint::black_box, time::Instant};

type Result<T> = std::result::Result<T, Box<dyn Error>>;

// Same explicit text, font, geometry and page count for every adapter.
fn lines(page: usize, pages: usize) -> Vec<String> {
    let mut lines = vec![format!("Invoice benchmark | Page {page:04}/{pages:04}")];
    for item in 1..=20 {
        lines.push(format!("Item {item:02} | Qty 2 | Unit 12.50 | Total 25.00"));
    }
    lines.push("TOTAL 500.00 EUR".into());
    lines
}

fn generate(library: &str, pages: usize) -> Result<Vec<u8>> {
    match library {
        "oxidize-pdf" => {
            use oxidize_pdf::{Document, Font, Page};
            let mut document = Document::new();
            for page in 1..=pages {
                let mut output = Page::a4();
                for (row, text) in lines(page, pages).iter().enumerate() {
                    output
                        .text()
                        .set_font(Font::Helvetica, 10.0)
                        .at(50.0, 790.0 - row as f64 * 20.0)
                        .write(text)?;
                }
                document.add_page(output);
            }
            Ok(document.to_bytes()?)
        }
        "pdf_oxide" => {
            use pdf_oxide::writer::{DocumentBuilder, PageSize};
            let mut document = DocumentBuilder::new();
            for page in 1..=pages {
                let mut output = document
                    .page(PageSize::Custom(595.276, 841.89))
                    .font("Helvetica", 10.0);
                for (row, text) in lines(page, pages).iter().enumerate() {
                    output = output.at(50.0, 790.0 - row as f32 * 20.0).text(text);
                }
                output.done();
            }
            Ok(document.build()?)
        }
        "pdf-writer" => {
            use pdf_writer::{Content, Finish, Name, Pdf, Rect, Ref, Str};
            let mut pdf = Pdf::new();
            let catalog = Ref::new(1);
            let tree = Ref::new(2);
            let font = Ref::new(3);
            let ids: Vec<_> = (0..pages).map(|i| Ref::new(4 + i as i32 * 2)).collect();
            pdf.catalog(catalog).pages(tree);
            pdf.pages(tree)
                .kids(ids.iter().copied())
                .count(pages as i32);
            pdf.type1_font(font).base_font(Name(b"Helvetica"));
            for (index, id) in ids.into_iter().enumerate() {
                let content = Ref::new(5 + index as i32 * 2);
                let mut page = pdf.page(id);
                page.media_box(Rect::new(0.0, 0.0, 595.276, 841.89));
                page.parent(tree).contents(content);
                page.resources().fonts().pair(Name(b"F1"), font);
                page.finish();
                let mut ops = Content::new();
                for (row, text) in lines(index + 1, pages).iter().enumerate() {
                    ops.begin_text();
                    ops.set_font(Name(b"F1"), 10.0);
                    ops.next_line(50.0, 790.0 - row as f32 * 20.0);
                    ops.show(Str(text.as_bytes()));
                    ops.end_text();
                }
                pdf.stream(content, &ops.finish());
            }
            Ok(pdf.finish())
        }
        "lopdf" => {
            use lopdf::{
                content::{Content, Operation},
                dictionary, Document, Object, Stream,
            };
            let mut document = Document::with_version("1.5");
            let tree = document.new_object_id();
            let font = document.add_object(
                dictionary! {"Type"=>"Font", "Subtype"=>"Type1", "BaseFont"=>"Helvetica"},
            );
            let resources = document.add_object(dictionary! {"Font"=>dictionary!{"F1"=>font}});
            let mut children = Vec::<Object>::new();
            for page in 1..=pages {
                let mut operations = Vec::new();
                for (row, text) in lines(page, pages).iter().enumerate() {
                    operations.extend([
                        Operation::new("BT", vec![]),
                        Operation::new("Tf", vec!["F1".into(), 10.into()]),
                        Operation::new("Td", vec![50.into(), (790.0 - row as f32 * 20.0).into()]),
                        Operation::new("Tj", vec![Object::string_literal(text.as_bytes())]),
                        Operation::new("ET", vec![]),
                    ]);
                }
                let stream = document.add_object(Stream::new(
                    dictionary! {},
                    Content { operations }.encode()?,
                ));
                children.push(
                    document
                        .add_object(dictionary! {"Type"=>"Page", "Parent"=>tree,"Contents"=>stream})
                        .into(),
                );
            }
            document.objects.insert(tree, Object::Dictionary(dictionary!{
                "Type"=>"Pages", "Kids"=>children, "Count"=>pages as i64,
                "Resources"=>resources,"MediaBox"=>vec![0.into(),0.into(),595.276.into(),841.89.into()]
            }));
            let catalog = document.add_object(dictionary! {"Type"=>"Catalog", "Pages"=>tree});
            document.trailer.set("Root", catalog);
            let mut bytes = Vec::new();
            document.save_to(&mut bytes)?;
            Ok(bytes)
        }
        "printpdf" => {
            use printpdf::*;
            let mut document = PdfDocument::new("Invoice benchmark");
            let mut output = Vec::new();
            for page in 1..=pages {
                let mut operations = Vec::new();
                for (row, text) in lines(page, pages).into_iter().enumerate() {
                    operations.extend([
                        Op::StartTextSection,
                        Op::SetTextCursor {
                            pos: Point {
                                x: Pt(50.0),
                                y: Pt(790.0 - row as f32 * 20.0),
                            },
                        },
                        Op::SetFont {
                            font: PdfFontHandle::Builtin(BuiltinFont::Helvetica),
                            size: Pt(10.0),
                        },
                        Op::ShowText {
                            items: vec![TextItem::Text(text)],
                        },
                        Op::EndTextSection,
                    ]);
                }
                output.push(PdfPage::new(Mm(210.0), Mm(297.0), operations));
            }
            let mut warnings = Vec::new();
            let bytes = document
                .with_pages(output)
                .save(&PdfSaveOptions::default(), &mut warnings);
            if !warnings.is_empty() {
                return Err(format!("serialization warnings: {warnings:?}").into());
            }
            Ok(bytes)
        }
        _ => Err("unknown library".into()),
    }
}

fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 5 {
        return Err("usage: generation LIBRARY SCENARIO OUTPUT.pdf DOCUMENTS".into());
    }
    let pages = match args[2].as_str() {
        "invoice-1p" => 1,
        "report-10p" => 10,
        _ => return Err("unknown scenario".into()),
    };
    let documents: usize = args[4].parse()?;
    if !(1..=10000).contains(&documents) {
        return Err("invalid document count".into());
    }
    for _ in 0..3 {
        black_box(generate(&args[1], pages)?);
    }
    let started = Instant::now();
    let mut output_bytes = 0u64;
    for _ in 0..documents {
        let bytes = generate(&args[1], pages)?;
        if bytes.is_empty() {
            return Err("empty PDF".into());
        }
        output_bytes += bytes.len() as u64;
        black_box(bytes);
    }
    let elapsed_ns = started.elapsed().as_nanos();
    // Independent validation/IO are outside the timed interval. RSS includes them.
    std::fs::write(&args[3], generate(&args[1], pages)?)?;
    println!(
        "{}",
        serde_json::json!({"documents":documents,"pages_per_document":pages,"warmup_documents":3,"elapsed_ns":elapsed_ns,"output_bytes":output_bytes})
    );
    Ok(())
}

# Generation performance protocol — pdf-generation-v1

Related scope: oxidizePdf #603, public claims supported by observable evidence.
This suite supplements the existing generation smoke baseline and OmniDocBench
quality evaluation. Quality, performance and adoption are separate populations.

## Reproduce

```sh
python3 benchmark/scripts/generation_benchmark.py --offline \
  --output benchmark/results/generation/NEW-RUN --samples 20
cargo run --locked --offline -- --config CONFIG.toml import-performance \
  --summary benchmark/results/generation/NEW-RUN/summary.json
```

Linux, GNU `/usr/bin/time`, qpdf, Poppler pdftotext and Rust/Cargo are required.
The generation crate has an independent committed lockfile and exact registry
pins for oxidize-pdf 5.1.5, lopdf 0.44.0, pdf-writer 0.15.0, printpdf 0.12.7
and pdf_oxide 0.3.78. pdf_oxide uses office_oxide 0.1.9, matching its published
lockfile: resolving office_oxide 0.1.12 fails with a missing DocumentIR field.
The original build failure is retained under
benchmark/results/generation/pdf-oxide-build-evidence/. No vendor code is patched.
Remove `--offline` for the initial dependency download. The source is
`benchmark/generation/src/main.rs`; orchestration is
`benchmark/scripts/generation_benchmark.py`. Updating a release requires changing
the exact pin and lock, then running into a **new directory**; never relabel an
old result. A changed workload/measurement definition requires a new protocol.
Runs are explicit, not automatically added to the OmniDocBench scheduler.

## Workload and measurement

- Same A4 page geometry, Helvetica 10pt, fixed 22 text lines per page and explicit
  coordinates in all adapters (pdf_oxide uses explicit A4 dimensions because its
  named A4 constant rounds to 595 × 842 points). There are no images, embedded fonts, charts or
  automatic table layout. These are synthetic invoice-like documents, not a
  representative invoice corpus. PDF metadata and serialization/compression
  defaults differ by adapter and output sizes are reported.
- `invoice-1p`: 1,000 separate one-page documents per sample. `report-10p`: 100
  separate ten-page documents per sample. Twenty complete blocks, each containing
  all engine/workload cases in seeded shuffled order (eight in the historical
  four-engine run, ten when pdf_oxide is included). No parallel benchmark processes.
- Each sample uses a fresh process with three warmup documents. The monotonic
  timed interval includes construction, text formatting, serialization to memory
  and buffer destruction. It excludes process startup, warmup, filesystem IO and
  independent validation. No PDF outputs are cached between timed documents.
- GNU time captures each process's maximum resident set in KiB, including runtime,
  warmup and the representative output write. This is **not incremental memory per
  document**, allocation count, leak measurement, or deployment image size.
  All adapters are linked into the same benchmark binary; RSS is not the size
  of a standalone application containing only that engine.
- One extra representative PDF per sample is retained; qpdf must return zero and
  the exact page count; pdftotext must reproduce all expected lines in page order.
  This verifies the shared text/page workload, not full visual equivalence, every
  timed output, or standards conformance. Failures stop the run; incomplete runs
  retain a failure record and never produce a successful summary.
- Raw elapsed nanoseconds and totals are retained. Medians use the midpoint of
  the two central observations; p95 uses nearest rank. Latency is **batch-average
  milliseconds per document**, so its p95 is not per-request tail latency.
  Throughput is computed per sample before aggregation. A seeded 2,000-resample
  percentile bootstrap estimates uncertainty of the observed median throughput;
  this is descriptive, not a confidence guarantee for other hosts/workloads.
- CPU, affinity, kernel, toolchain, flags, independent-validator versions, load,
  registry package identities, lockfile and source/binary hashes are recorded.
  This is a shared host, not a dedicated isolated performance lab. Comparisons
  belong to the same run; do not pool different CPUs, protocols or compiler flags.

## Artifacts and dashboard

Each run contains `manifest.json`, `samples.jsonl`, `summary.json`, `report.md`,
source snapshots, Cargo manifest/lock, one representative PDF and RSS reading
per sample (160 in the original run, 200 with five engines).
The importer verifies artifact hashes, case completeness, exact sample identities,
version provenance, validation records and recomputes medians/p95/throughput/RSS/
size before storing an immutable, content-addressed run. A duplicate import is
idempotent; a different run is retained separately. The local collector owns
imports; the dashboard's `/api/performance` endpoint is read-only.

A separate generation panel displays all engines in each run with sample counts,
versions, workload and environment. It does not rank mixed environments or
combine performance with extraction accuracy. New migration 16 adds only the
performance history table. Review and preview use an isolated database; no
production migration or deployment is needed to inspect the result.

## Initial measurement

[2026-09-28 report](../benchmark/results/generation/2026-09-28-v1/report.md):
20 samples per case, 88,000 timed documents and 160,000 timed pages across four
engines; 160 representative PDFs independently checked. In these workloads the
other three engines are faster than oxidize-pdf. Preserve that result, rather
than selecting a favorable scenario or claiming general superiority.

These results support a bounded generation-throughput statement. They do not
support the previous PDFSharp/QuestPDF/IronPDF comparisons, zero-leak promises,
ROI figures, container sizes, or claims about arbitrary PDF workloads.

## pdf_oxide extension

The engine cohort is recorded in each manifest. The importer accepts both the
historical four-engine cohort and the five-engine cohort including pdf_oxide;
it requires both workloads and all blocks for every declared engine, and rejects
unknown engines. Historical artifacts are unchanged. Adding an engine changes
the randomized execution order, so all engines are rerun together. The dashboard
keeps each run separate and displays its declared engines dynamically.

A preliminary five-engine attempt stopped before measurement because an offline
Cargo metadata dependency was not cached. It has no successful summary and is
retained separately; dependencies were then fetched before retrying offline.

## Five-engine measurement including pdf_oxide

[Completed run](../benchmark/results/generation/2026-09-28-v1-five-engines-attempt-2/report.md):
200 samples, 110,000 timed documents, 200,000 timed pages and 200 independently
validated representative PDFs. All five engines were rerun together. The one-page
median bootstrap intervals overlap for oxidize-pdf/pdf_oxide, so median ordering
is not a conclusive speed ranking. Changes from the older run are not code
improvements: do not pool executions with different cohort/binary/environment.

## Recorded interpretation and project intent — 2026-09-28

The user requested pdf_oxide out of curiosity. Beating pdf_oxide is explicitly
**not a project objective**, performance target, or acceptance criterion. This
comparison does not authorize optimization work or change roadmap priorities.

Documents/second measures throughput: higher is better. Milliseconds/document
measures elapsed time: lower is better. Ratios below compare median throughput
within the completed five-engine run, not p95 against medians.

| Synthetic workload | oxidize-pdf docs/s | pdf_oxide docs/s | pdf-writer docs/s | pdf-writer / oxidize-pdf |
|---|---:|---:|---:|---:|
| One page | 6,311.4 | 6,630.9 | 116,236.9 | 18.42× |
| Ten pages | 732.4 | 923.2 | 13,064.2 | 17.84× |

pdf_oxide's observed throughput advantage is approximately 5% for one page and
26% for ten pages. The one-page bootstrap intervals overlap; the ten-page
intervals do not. Overlap does not prove equality, and these descriptive
intervals alone are not a formal paired comparison test.

pdf-writer has a large observed advantage in both measured workloads, roughly
18 times the throughput of oxidize-pdf. Preserve this unfavorable result. It is
not a measurement of parsing, extraction, complex layout, or overall feature
equivalence; serialization/compression defaults and output sizes differ. The
benchmark does not establish the cause of the performance gap or create an
optimization commitment against either library.

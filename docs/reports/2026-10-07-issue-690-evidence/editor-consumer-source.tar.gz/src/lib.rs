#![cfg(test)]
mod editor_support;
use editor_support::{preflight_tagged_pdf,prepare_tagged_pdf,TaggedPdfMetadata};

use std::{collections::BTreeMap, fs};

fn encode_tagged_fixture_with_absent_references(
    objects: BTreeMap<u32, Vec<u8>>,
    missing_indexes: bool,
    bad_metadata: bool,
    additional_absent: &[u32],
) -> Vec<u8> {
    let size = objects.keys().max().copied().unwrap() + 1;
    let mut bytes = b"%PDF-1.4\n".to_vec();
    let mut offsets = BTreeMap::new();
    for (id, object) in objects {
        offsets.insert(id, bytes.len());
        bytes.extend_from_slice(format!("{id} 0 obj\n").as_bytes());
        bytes.extend(object);
        bytes.extend_from_slice(b"\nendobj\n");
    }
    let xref = bytes.len();
    bytes.extend_from_slice(format!("xref\n0 {size}\n0000000000 65535 f \n").as_bytes());
    for id in 1..size {
        let in_use = offsets.contains_key(&id)
            || (missing_indexes && (id == 6 || id == 7))
            || (bad_metadata && id == 9)
            || additional_absent.contains(&id);
        bytes.extend_from_slice(
            format!(
                "{:010} 00000 {} \n",
                offsets.get(&id).copied().unwrap_or(0),
                if in_use { 'n' } else { 'f' }
            )
            .as_bytes(),
        );
    }
    bytes.extend_from_slice(
        format!("trailer\n<< /Size {size} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n").as_bytes(),
    );
    bytes
}

fn representative_source_shape_fixture(
    flat_tree: bool,
    language: bool,
    descriptions: bool,
) -> Vec<u8> {
    let shape: serde_json::Value = serde_json::from_str(include_str!("fixture.json")).unwrap();
    let mut objects = BTreeMap::new();
    objects.insert(1, format!("<< /Type /Catalog /Version /1.4 /Pages 2 0 R /MarkInfo << /Marked true >> /StructTreeRoot 3 0 R {} >>", if language { "/Lang (en-US)" } else { "" }).into_bytes());
    let leaves = (10..22).map(|id| format!("{id} 0 R")).collect::<Vec<_>>();
    objects.insert(
        2,
        format!(
            "<< /Type /Pages /Count 12 /Kids [{}] >>",
            if flat_tree {
                leaves.join(" ")
            } else {
                "22 0 R 23 0 R".to_string()
            }
        )
        .into_bytes(),
    );
    if !flat_tree {
        objects.insert(
            22,
            format!(
                "<< /Type /Pages /Parent 2 0 R /Count 8 /Kids [{}] >>",
                leaves[..8].join(" ")
            )
            .into_bytes(),
        );
        objects.insert(
            23,
            format!(
                "<< /Type /Pages /Parent 2 0 R /Count 4 /Kids [{}] >>",
                leaves[8..].join(" ")
            )
            .into_bytes(),
        );
    }
    objects.insert(
        3,
        b"<< /Type /StructTreeRoot /K 4 0 R /ParentTree 6 0 R /IDTree 7 0 R >>".to_vec(),
    );
    objects.insert(
        8,
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>".to_vec(),
    );
    let mut structure_children = Vec::new();
    for (page_index, items) in shape["pages"].as_array().unwrap().iter().enumerate() {
        let page_id = 10 + page_index;
        let parent = if flat_tree {
            2
        } else if page_index < 8 {
            22
        } else {
            23
        };
        let mut content = String::new();
        for (row, item) in items.as_array().unwrap().iter().enumerate() {
            let mcid = item[0].as_u64().unwrap();
            let role = item[1].as_str().unwrap();
            let has_description = item[2].as_bool().unwrap();
            let structure_id = 1000 + mcid as u32;
            structure_children.push(format!("{structure_id} 0 R"));
            objects.insert(
                structure_id,
                format!(
                    "<< /Type /StructElem /S /{role} /P 4 0 R /Pg {page_id} 0 R /K {mcid} {} >>",
                    if role == "Figure" && (has_description || descriptions) {
                        "/Alt (Synthetic description)"
                    } else {
                        ""
                    }
                )
                .into_bytes(),
            );
            content.push_str(&format!("/{role} << /MCID {mcid} >> BDC BT /F1 2 Tf 10 {} Td (synthetic item {mcid}) Tj ET EMC\n", 290.0 - row as f64 * 2.6));
        }
        let stream_id = 30 + page_index;
        objects.insert(page_id as u32, format!("<< /Type /Page /Parent {parent} 0 R /MediaBox [0 0 300 300] /Resources << /Font << /F1 8 0 R >> >> /Contents {stream_id} 0 R >>").into_bytes());
        objects.insert(
            stream_id as u32,
            format!(
                "<< /Length {} >>\nstream\n{content}endstream",
                content.len()
            )
            .into_bytes(),
        );
    }
    objects.insert(
        4,
        format!(
            "<< /Type /StructElem /S /Document /P 3 0 R /K [{}] >>",
            structure_children.join(" ")
        )
        .into_bytes(),
    );
    let mut bytes =
        encode_tagged_fixture_with_absent_references(objects, true, false, &[9, 26, 27, 28]);
    bytes[..8].copy_from_slice(b"%PDF-1.3");
    bytes
}

#[test]
fn complete_690_candidate_acceptance() {
    use oxidize_pdf::{
        operations::{ExistingDocumentPolicy, PageRange, existing_document::split_pdf},
        parser::PdfReader,
        verification::tagged_pdf::validate_tagged_pdf,
    };
    for flat in [false,true] {
        let original=representative_source_shape_fixture(flat,false,false);
        let preflight=preflight_tagged_pdf(&original).unwrap();assert_eq!(preflight.findings.len(),3);
        assert!(prepare_tagged_pdf(&original,&TaggedPdfMetadata::default()).is_err());
        let prepared=prepare_tagged_pdf(&original,&TaggedPdfMetadata {language:Some("es-ES".into()),alternate_text:BTreeMap::from([((1452,0).into(),"Explicit synthetic description one".into()),((1453,0).into(),"Explicit synthetic description two".into())])}).unwrap();
        let directory=tempfile::tempdir().unwrap();let source=directory.path().join("source.pdf");fs::write(&source,&original).unwrap();
        let prepared_path=directory.path().join("prepared.pdf");fs::write(&prepared_path,&prepared.pdf_bytes).unwrap();
        let before=PdfReader::open_document(&source).unwrap().extract_text().unwrap();
        let outputs=(0..3).map(|i|directory.path().join(format!("part{i}.pdf"))).collect::<Vec<_>>();
        for path in &outputs {fs::write(path,b"existing destination").unwrap();}
        split_pdf(&prepared_path,&[PageRange::List(vec![0,1,2]),PageRange::List(vec![3,4,5]),PageRange::List(vec![6,7,8,9,10,11])],&outputs,ExistingDocumentPolicy::preserve_base()).unwrap();
        for (path,(start,end)) in outputs.iter().zip([(0,3),(3,6),(6,12)]) {
            let bytes=fs::read(path).unwrap();assert!(bytes.starts_with(&original));
            let tags=validate_tagged_pdf(&bytes,&Default::default()).unwrap();assert!(tags.valid);assert_eq!(tags.parent_tree_entries,end-start);
            let after=PdfReader::open_document(path).unwrap().extract_text().unwrap();assert_eq!(after.len(),end-start);
            for (a,b) in after.iter().zip(&before[start..end]) {assert_eq!(a.text,b.text);}
        }
        assert_eq!(fs::read(&source).unwrap(),original);
    }
}

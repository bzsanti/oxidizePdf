use oxidize_pdf::{error::Result, writer::{IncrementalTaggedPdfEditor, TaggedPdfMutation, TaggedPdfMutationReport, TaggedPdfChangedObjectKind}, parser::objects::{PdfObject, PdfString}, verification::tagged_pdf::{TaggedPdfObjectRef,TaggedPdfValidationReport}};
use std::collections::BTreeMap;
// Compile-time compatibility: existing exhaustive consumers still compile.
const _: fn(TaggedPdfChangedObjectKind)->u8 = |kind| match kind {
 TaggedPdfChangedObjectKind::StructureElement=>0,
 TaggedPdfChangedObjectKind::StructureTreeRoot=>1,
 TaggedPdfChangedObjectKind::ParentTree=>2,
 TaggedPdfChangedObjectKind::CrossReference=>3,
};
#[derive(Default)]
pub struct TaggedPdfMetadata { pub language:Option<String>, pub alternate_text:BTreeMap<TaggedPdfObjectRef,String> }
pub fn preflight_tagged_pdf(bytes:&[u8])->Result<TaggedPdfValidationReport> {IncrementalTaggedPdfEditor::new(bytes).preflight()}
pub fn prepare_tagged_pdf(bytes:&[u8],values:&TaggedPdfMetadata)->Result<TaggedPdfMutationReport> {
 let mut editor=IncrementalTaggedPdfEditor::new(bytes).with_recovered_indexes()?;
 if let Some(language)=&values.language {editor=editor.with_document_language(language)?;}
 let mutations:Vec<_>=values.alternate_text.iter().map(|(element,value)|{
 let mut encoded=vec![0xfe,0xff];for unit in value.encode_utf16(){encoded.extend_from_slice(&unit.to_be_bytes());}
 TaggedPdfMutation::SetElementAttribute{element:*element,key:"Alt".into(),value:Some(PdfObject::String(PdfString::new(encoded)))}
 }).collect();
 let plan=editor.plan(&mutations)?;let result=editor.apply(&mutations)?;assert_eq!(plan,result.plan);Ok(result)
}
